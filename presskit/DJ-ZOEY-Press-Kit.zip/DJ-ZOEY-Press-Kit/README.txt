DJ ZOEY – Press Kit / 宣传资料

DJ-ZOEY-Press-Kit.pdf   Bio (EN/中文), logo, contacts
Logo/                   Logo white (dark backgrounds) / black (light backgrounds) · 白色（深色背景）/ 黑色（浅色背景）

Booking: babyzhouzz@gmail.com · WeChat 微信: zoeyisgirl
Website: https://dj-zoey.github.io

Please use the logo only to promote DJ ZOEY's performances.
标志仅可用于宣传 DJ ZOEY 的演出。
