DJ ZOEY – Press Kit / 宣传资料

DJ-ZOEY-Press-Kit.pdf   Bio (EN/中文), photos, logo, contacts
Photos/                 Press photos · 宣传照片
Logo/                   Logo white (dark backgrounds) / black (light backgrounds) · 白色（深色背景）/ 黑色（浅色背景）

Booking: babyzhouzz@gmail.com · WeChat 微信: zoeyisgirl
Website: https://dj-zoey.github.io

Please use logo and photos only to promote DJ ZOEY's performances.
标志和照片仅可用于宣传 DJ ZOEY 的演出。
